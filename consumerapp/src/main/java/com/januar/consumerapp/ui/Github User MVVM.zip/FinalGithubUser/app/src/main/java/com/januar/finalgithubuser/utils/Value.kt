package com.januar.finalgithubuser.utils

object Value {

    //TOKEN: 888d4c00c00c22d11621d3ba05d945c541a30996
    const val mainData = "datamain"
    const val URLData = "https://api.github.com/"
    const val API_KEY = "888d4c00c00c22d11621d3ba05d945c541a30996"
}