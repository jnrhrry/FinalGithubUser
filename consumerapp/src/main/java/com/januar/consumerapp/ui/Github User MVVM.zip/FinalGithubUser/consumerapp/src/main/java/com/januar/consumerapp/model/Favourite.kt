package com.januar.consumerapp.model

data class Favorite(
    val id: Long,
    val login: String?,
    val avatar_url:String
)